/*
 * UART.h
 *
 *  Created on: Sep 23, 2012
 *      Author: konstantin
 */

void UART1_Configuration(void);
void UART2_Configuration(void);
void UART2_Configuration_AT(uint32_t);
