/*
 * ADC.c
 *
 *  Created on: Nov 13, 2010
 *      Author: konstantin
 */


void ADC1_Configuration(void);

